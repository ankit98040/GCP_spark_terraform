# intro

Create a Bucket.

## Architecture

Below is an architectural image created after Terraform is executed.

![alt text](./images/40_cloud_storage.drawio.png)
