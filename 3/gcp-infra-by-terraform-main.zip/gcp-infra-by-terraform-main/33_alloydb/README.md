# intro
Create a AlloyDB.

## Architecture
Below is an architectural image created after Terraform is executed.

![alt text](./images/33_alloydb.drawio.png)