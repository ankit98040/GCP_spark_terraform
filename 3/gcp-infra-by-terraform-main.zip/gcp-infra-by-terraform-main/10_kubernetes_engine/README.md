# intro
Create a GKE cluster.

## Architecture
Below is an architectural image created after Terraform is executed.

![alt text](./images/gke.png)