# intro
Create one topic and two subscriptions. Subscriptions are push and pull respectively.

## Architecture
Below is an architectural image created after Terraform is executed.

![alt text](./images/60_cloud_pubsub.drawio.png)