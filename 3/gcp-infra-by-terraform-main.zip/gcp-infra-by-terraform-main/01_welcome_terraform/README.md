# intro
This is a basic example for training Terraform. Create a VPC in the cloud.

## Architecture
Below is an architectural image created after Terraform is executed.

![alt text](./images/vpc.png)