# intro
Create a sppanner database.

## Architecture
Below is an architectural image created after Terraform is executed.

![alt text](./images/39_spanner.drawio.png)